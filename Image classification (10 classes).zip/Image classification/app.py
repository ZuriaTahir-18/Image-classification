from flask import Flask, render_template,request
from keras.models import load_model
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


model = load_model('model.h5')

classes = ["airplane","automobile","bird","cat","deer","dog","frog","horse","ship","truck"]

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if request.method == 'POST':

        if 'image' in request.files:
            image = request.files['image']

            image = Image.open(image)
            resized_image = image.resize((32, 32))
            image_array = np.array(resized_image)

            image_reshaped = np.expand_dims(image_array, axis=0)
            predictions = model.predict(image_reshaped)

            y_class = [np.argmax(element) for element in predictions][0]

            output = classes[y_class]

            return render_template('index.html', output=output)
        
        else:
            return 'No image uploaded!'
    else:
        return 'Invalid request method'

if __name__ == '__main__':
    app.run(debug=True)